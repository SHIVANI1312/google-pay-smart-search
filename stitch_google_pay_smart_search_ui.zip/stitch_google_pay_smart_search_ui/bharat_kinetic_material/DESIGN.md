---
name: Bharat Kinetic Material
colors:
  surface: '#f8faf7'
  surface-dim: '#d8dbd8'
  surface-bright: '#f8faf7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f1'
  surface-container: '#eceeec'
  surface-container-high: '#e7e9e6'
  surface-container-highest: '#e1e3e0'
  on-surface: '#191c1b'
  on-surface-variant: '#424654'
  inverse-surface: '#2e3130'
  inverse-on-surface: '#eff1ef'
  outline: '#737785'
  outline-variant: '#c3c6d6'
  surface-tint: '#0856cf'
  primary: '#0041a2'
  on-primary: '#ffffff'
  primary-container: '#0b57d0'
  on-primary-container: '#ced9ff'
  inverse-primary: '#b2c5ff'
  secondary: '#076d2e'
  on-secondary: '#ffffff'
  secondary-container: '#9cf7a7'
  on-secondary-container: '#147434'
  tertiary: '#6c3b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#8e4f00'
  on-tertiary-container: '#ffd0a9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001847'
  on-primary-fixed-variant: '#0040a1'
  secondary-fixed: '#9cf7a7'
  secondary-fixed-dim: '#81da8d'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#ffdcc0'
  tertiary-fixed-dim: '#ffb876'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6b3b00'
  background: '#f8faf7'
  on-background: '#191c1b'
  surface-variant: '#e1e3e0'
typography:
  display-currency:
    fontFamily: Roboto Flex
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.5px
  display-currency-mobile:
    fontFamily: Roboto Flex
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.5px
  headline-lg:
    fontFamily: Roboto Flex
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Roboto Flex
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Roboto Flex
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.15px
  body-lg:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  body-sm:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.4px
  label-lg:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-md:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: Roboto Flex
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.5px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.5rem
  margin: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies the effortless speed, high-trust security, and everyday utility of peer-to-peer and merchant payments across India. Built on the principles of Material Design 3 (Material You), the visual identity balances institutional reliability with approachable, human interactions tailored for diverse, multilingual user touchpoints.

### Personality & Values
- **Frictionless & Decisive:** Visual interactions resolve within milliseconds, prioritizing clear transaction states and zero ambiguity.
- **Trustworthy & Secure:** Financial boundaries are clearly demarcated through distinct surface containers and consistent state signifiers.
- **Accessible & Culturally Nuanced:** Optimized for high-density information display, vernacular clarity, and native Indian Rupee (`₹`) metric prominence.

### Design Movement
**Modern Material You (MD3 Evolution):** Clean tonal surface architectures, high-radius organic geometry (16px to 28px), pill-shaped containers, and elevation-0 surfaces delimited by subtle tonal outlines rather than heavy drop shadows.

## Colors

The palette utilizes canonical Google foundational primaries translated into Material 3 state-aware tones, anchoring primary actions in Google Blue while preserving Green, Yellow, and Red for systemic transaction feedback.

### Key Roles
- **Primary (`#0B57D0`):** Core interactive states, active search rings, primary CTA fills, and authenticated state indicators.
- **Secondary / Success (`#137333`):** Successful UPI payment processing, verified merchant badges, and positive cash flow states.
- **Tertiary / Warning (`#EA8600`):** Pending mandates, processing states, bill payment dues, and rewards badges.
- **Error / Danger (`#B3261E`):** Transaction failures, bank server timeouts, fraud warnings, and decline prompts.
- **Surface Foundations:** Background canvas utilizes `#F8F9FA` (Surface Container Lowest/Low), stepping up to `#FFFFFF` for primary cards and interaction tiles. Subtle outlines utilize `#E0E3E7` for low-contrast borders and `#747775` for unselected icon/border lines.

## Typography

The type system prioritizes high-legibility numerical processing and seamless inclusion of the Indian Rupee symbol (`₹`). Using Roboto Flex delivers native Android parity, variable-width adaptability for localized Indian scripts, and uniform visual weight between monetary digits and companion currency symbols.

### Implementation Rules
- **Currency Standard:** The Rupee symbol (`₹`) is always rendered at 90% the cap-height of adjacent numerical digits to maintain horizontal equilibrium, sharing the same font weight and color token.
- **Hierarchical Anchors:** Numerical data in `display-currency` uses medium-to-semibold weights (`600`) to guarantee clear readability during rapid in-store transactions.
- **Labels & Microcopy:** `label-md` and `label-sm` govern status chips, timestamp footers, and transaction IDs with extended letter spacing for scannability on low-density mobile displays.

## Layout & Spacing

Layouts adhere strictly to an 8-point baseline grid with a 4-point micro-step for compact metadata badges and avatars. Mobile execution operates as a fluid column framework framed by strict horizontal edge paddings.

### Layout Mechanics
- **Mobile Handheld (0-599px):** 4-column fluid layout with a `1rem` (16px) outer margin and `1rem` gutter. 
- **Tablet / Large Foldable (600-840px):** 8-column layout with `2rem` outer margins, centering monetary action drawers within standard thumb-reach zones.
- **Section Rhythm:** A consistent vertical cadence of `1.5rem` (`space-lg`) separates dashboard groups (e.g., 'People', 'Businesses', 'Bills & Recharges'). Content within cards uses `space-md` (16px) internal padding.

## Elevation & Depth

Visual separation relies on Material Design 3 surface containers and hairline borders rather than heavy skeuomorphic cast shadows.

### Surface Tiers
- **Surface Canvas (Lowest):** `#F8F9FA` forms the infinite scroll canvas.
- **Surface Container (Base):** `#FFFFFF` surfaces distinguish interactive cards, merchant tiles, and utility panels.
- **Surface Container High:** `#F1F3F4` establishes recessed areas like the top search pill, transaction memo fields, and keypad backdrops.

### Outlines & Borders
To preserve modern clean aesthetics, containers feature an Elevation-0 paradigm:
- Hairline structural border: `1px solid #E0E3E7`.
- Hover/Pressed focus border: `1.5px solid #0B57D0`.
- Shadows are avoided except for transient elements (such as bottom sheets and floating action pills), which utilize an ambient soft blur: `0px 4px 12px rgba(0, 0, 0, 0.08)`.

## Shapes

The design system adopts Material You's expressive organic shape language, using high corner radii to communicate touch-friendly, secure UI components.

### Curvature Taxonomy
- **Small Elements (Input fields, Chips):** Fully pill-shaped (`9999px`) or `rounded-lg` (16px).
- **Cards & Surface Tiles:** Defined at `rounded-xl` (24px to 28px) for modular transaction groupings and promotions.
- **Primary Buttons & FABs:** Fully pill-shaped (`9999px`) for unambiguous action hierarchy.
- **Contact & Merchant Nodes:** Strictly circular (`50%` / full round) for personal avatars, bank logos, and UPI target icons.

## Components

### Top Search & Command Pill
- **Structure:** Floating, elevation-0 container with `#F1F3F4` fill, height `48px`, border-radius `9999px`.
- **Anatomy:** 
  - Left: Search icon (`#747775`) + localized placeholder text ("Pay anyone on UPI").
  - Right cluster: QR Scanner icon button (touch target `40px`), Voice Search microphone icon, and user profile avatar (`32px` circle with Google account indicator ring).

### Action Buttons
- **Primary Buttons:** Pill-shaped (`rounded-full`), minimum height `48px`, `#0B57D0` background fill with `#FFFFFF` text (`label-lg`). Zero elevation at rest; ripple state active on touch.
- **Tonal / Secondary Buttons:** `#E8F0FE` fill with `#0B57D0` text for non-destructive actions like "Split an expense" or "Check balance".
- **Outlined Buttons:** `1px solid #747775` border, transparent background, pill-shaped.

### Chips & Filter Tokens
- **Pill Chips:** Height `32px`, pill radius (`9999px`).
- **Unselected:** Transparent background, `1px solid #E0E3E7` border, `#1F1F1F` text.
- **Selected:** `#E8F0FE` fill, `#0B57D0` text, optional leading checkmark icon.

### Avatar Grids (People & Businesses)
- **Grid Density:** 4 columns across mobile viewports.
- **Avatar Architecture:** `56px` circular containers. Personal contacts display high-contrast typography initials or profile photography. Verified business contacts display circular branded imagery with an overlapping `16px` Material blue verification badge at bottom-right.
- **Labeling:** Single-line truncated name (`body-sm`), centered below avatar with `4px` top margin.

### Surface Cards & Bank Containers
- **Container Architecture:** `#FFFFFF` fill, `24px` border radius, `1px solid #E0E3E7` outer outline. Internal padding `16px`.
- **Payment Request Card:** Two-column split featuring payee name, timestamp, and a prominent right-aligned Rupee amount (`headline-sm`). Includes explicit inline dual-action pill buttons: "Pay" (filled `#0B57D0`) and "Decline" (outlined `#E0E3E7`).

### Input Fields & UPI Amount Keypads
- **Amount Input:** Centralized screen alignment, elevation-0 background. Displays large Rupee glyph (`display-currency`) preceding a flashing Google Blue caret (`#0B57D0`).
- **Standard Inputs:** Floating label style with `16px` border-radius or filled container (`#F1F3F4`) with active bottom stroke transitioning to `#0B57D0`.

### Selection Controls
- **Radio & Checkbox:** Native Material 3 scale (`20px`). Checked state uses `#0B57D0` fill with white indicator; unchecked features `2px solid #747775` ring.